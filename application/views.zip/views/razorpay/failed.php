<?php  $admin_url = $this->config->item('admin_url'); ?> 
<div class="item active inner_pages">
  <img src="<?php echo base_url('assets/img/cart.jpg');?>" alt=" ">                      
  <div class="theme-container container">
    <div class="caption-text">
      <div class="cart_banner">
        <div class="inner_bg">
        <h3>Orders</h3>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="container">
    <div class="col-lg-12">
        <h4 class="success">your transaction was failed</h4>
    </div>
</div>