<!-- top sec -->
<!-- <div class="item active inner_pages">-->
<!--  <img src="<?php echo base_url('assets/img/cart.jpg');?>" alt=" ">                      -->
<!--  <div class="theme-container container">-->
<!--    <div class="caption-text">-->
<!--      <div class="cart_banner">-->
<!--        <div class="inner_bg">-->
<!--        <h3>Return Policy </h3>-->
<!--        </div>-->
<!--      </div>-->
<!--    </div>-->
<!--  </div>-->
<!--</div>-->
<div class="service_all">
<section class="service_top_sec">
  <div class="container">
        <div class="about_top_title main_title">
          <!--  <strong><h1 class="">Terms And   <span>Conditions</span></h1></strong>  -->
        </div>
  </div>
       
</section>
<!-- end s-home -->

<!-- about_sec -->
<section > 
  <div class="container">
    <div class="row about_ifno">
        <div class="col-md-12 col-xs-12">
            <p>We offer a hassle free 7 day Exchange policy on our exchangeable** products. If you do not like a product or it does not fit well, then we will issue you store credit in form of a Credit Note that can be used to purchase anything you like. Please follow these steps to initiate a return:
            </p>
            <ul><li>You can email us at support@hepppp.com or call us at 8886089801 within 7 days of receiving the product. Please mention your order number and the product you want to return.</li>
<li>Once we receive your request, we will initiate the pickup from the shipping address mentioned in your original order.</li>
<li>We do not offer reverse pickup service for International orders where the address is outside of India. The customer will have the bear the cost of shipping the goods to us. In case you want to exchange a product, please send it to the following address:
Vardhaman Enterprises, 101/A, First Floor, Road No:70, Journalist Colony, Jubilee Hills, Hyderabad – 500033, Telangana, INDIA.</li>
<li>Please hand over the product to our logistics partner when they come to your doorstep. Please note the product must be unused and unwashed for hygiene reasons. Also the product tags should be intact with its original packing; else we will not be able to process your return. Reverse Pickup usually takes 1-3 days from the day the request is initiated.</li>
<li>After we receive the return, the product will go through a quality check. Please note that it takes 7-10 days for us to receive the returned product.</li>
<li>Finally, after the product passes the quality check, we will issue you a store credit in form of a Credit Note that will be emailed to your original order email address. The Credit Note will have a 6 month expiry and can be used to purchase anything from our store.</li>
</ul>
<h3>**Pre-Ordered products cannot be exchanged. Used, washed, damaged or laundered products cannot be exchanged. Products tags and original packing must be intact to avail exchange.</h3>
<h3>Good To Know:</h3>
<ul>
<li>We offer reverse pick up for majority of pin-codes in India. But if reverse pick up is not available for your pin-code, then we would request you to send the product back to us at the following address: Vardhaman Enterprises, 101/A, First Floor, Road No:70, Journalist Colony, Jubilee Hills, Hyderabad – 500033, Telangana, INDIA.</li>
<li>We can only offer exchanges based on availability of size upon receiving the return product and not before that.</li>
<li>	Please allow up to 3 working days to get your Credit Note after we have received the return product.</li>
<li>Images on the website are professionally clicked due to which sometimes the colour of actual product may vary from the image taken.</li>
<li>Shipping charges are not refundable.</li>
<li>	In case a product is missing from your shipment or a product is damaged in transit, please call or email us within 24 hours of the receipt of the shipment for us to investigate further.</li>
<li>We do not offer reverse pickup service for International orders where the address is outside of India. In case you want to exchange a product, please send it to the following address: Vardhaman Enterprises, 101/A, First Floor, Road No: 70, Journalist Colony, Jubilee Hills, Hyderabad – 500033, Telangana, INDIA.</li>
</ul>
<h3>Cancel the order?</h3>
<p>An order can be cancelled until the order is dispatched, applicable only to non pre-order products. Orders with pre-order products can be cancelled only within 24 hours of placing the order. Please call us on 8886089801 or email us at support@hepppp.com to cancel your order. If the order is shipped, we cannot cancel the order.</p>
<h3>Products on Demand (Preorder)</h3>
<p>
Some of the products made available on our Website are products manufactured on demand of the users. We have explicitly stated against such products that they are “Products on Demand”. Any orders made against such “Products on Demand” will be shipped by us within 15 to 20 days of placing the Order. You may at any time after the placing the Order contact our Customer Support Executives to know the status of your Orders. All provisions relating to delivery timelines shall be applicable on such products from the date of shipment of such products.</p>
<p>Notwithstanding anything mentioned in aforementioned provisions, we do not guarantee that delivery will happen within any specific timelines as it is completely dependent on the shipment services. Sometimes, delivery may take longer duration due to:</p>
•	Bad weather conditions;
•	Transportation delays;
•	Political disruptions; or
•	Other unforeseen circumstances
In such cases, we will proactively reach out to you. Please check your emails for such updates.
To the maximum extent permissible by law, We shall not be liable to You or any other persons for any direct, indirect, incidental, punitive, exemplary, special, consequential damages or loss of profits, revenue or goods will incurred by You due to any delay in the delivery of orders.



</p>
            
            
        </div>
    </div>
  </div>
</section>
</div>
<!-- about_sec -->
