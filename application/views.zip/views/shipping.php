<!-- top sec -->
 <div class="item active inner_pages">
  <img src="<?php echo base_url('assets/img/cart.jpg');?>" alt=" ">                      
  <div class="theme-container container">
    <div class="caption-text">
      <div class="cart_banner">
        <div class="inner_bg">
        <h3>Shipping Policy</h3>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="service_all">
<section class="service_top_sec">
  <div class="container">
        <div class="about_top_title main_title">
          <!--  <strong><h1 class="">Terms And   <span>Conditions</span></h1></strong>  -->
        </div>
  </div>
       
</section>
<!-- end s-home -->

<!-- about_sec -->
<section > 
  <div class="container">
    <div class="row about_ifno">
        <div class="col-md-12 col-xs-12">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>
            
            <h3>Lorem Ipsum is simply dummy text</h3>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>

            <h3>Lorem Ipsum is simply dummy text</h3>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
          
             <h3>Lorem Ipsum is simply dummy text</h3>
             <ul>
               <li>Lorem Ipsum is simply dummy text</li>
               <li>scrambled it to make a type specimen book</li>
               <li>It was popularised in the 1960s</li>
               <li>Ipsum passages, and more recently with desktop</li>
               <li>including versions of Lorem Ipsum.</li>
               <li>Lorem Ipsum is simply dummy text</li>
               <li>desktop publishing software like Aldus </li>
             </ul>
        </div>
    </div>
  </div>
</section>
</div>
<!-- about_sec -->
